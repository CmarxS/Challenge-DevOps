package br.com.fiap.Challenge_Mottu;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ChallengeMottuApplicationTests {

	@Test
	void contextLoads() {
	}

}
